<?php
/**
* Plugin Name: wpsync webspark
* Description: sync of Products in WordPress
* Version: 1.0.2
* Author: #
*/

if( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if( ! class_exists('WebsparkProdSync') ) :

	define( 'WPS_PATH', plugin_dir_path( __FILE__ ) );
	define( 'WPS_URL', plugin_dir_url( __FILE__ ) );

	class WebsparkProdSync {
		private $interval = 'hourly';
		private $api_url = 'https://wp.webspark.dev/wp-api/products';

		function __construct() {
			$this->setup_actions();
		}

		/* add hooks */
		public function setup_actions() {
			//
			register_activation_hook( __FILE__, [ $this, 'plugin_activate' ] );
			register_deactivation_hook( __FILE__, [ $this, 'plugin_deactivate' ] );
			add_action( 'wps_shedule', [ $this, 'get_leftover_products' ] );
			//

		}

		/* activate plugin callback */
		public function plugin_activate() {
			wp_clear_scheduled_hook( 'wps_shedule' );
			wp_schedule_event( time(), $this->interval, 'wps_shedule' );
		}

		/* Deactivate plugin callback */
		public function plugin_deactivate() {
			wp_clear_scheduled_hook( 'wps_shedule' );
		}

		/* update products */
		public function get_leftover_products() {
			$response = wp_remote_get( $this->api_url );  //can add 'timeout' parameter, by default 5sec
			
			if ( wp_remote_retrieve_response_code( $response ) == '200' && isset( $response['body'] ) ) {
				$data = json_decode( $response['body'], true );
				if ( $data['error'] ) {
					return;
				}
				
				//maybe some additional security data check can be here

				$items = array_column( $data['data'], null, 'sku' ); //make associative array with 'sku' as key
				$this->update_products( $items );
			}
		}

		//
		private function update_products( $new_items ) {
			if( !$new_items || !is_array( $new_items ) ) return;

			// get all products, then compare sku
			$all_prod = wc_get_products([
				'posts_per_page' => -1,
			]);
			//update or remove products
			if ( $all_prod ) {
				foreach ( $all_prod as $prod ) {
					$sku = $prod->get_sku();

					//remove old thumbnail file here, and then add new when update
					$th_id = get_post_thumbnail_id( $prod->get_id() );
					if ( $th_id ) {
						wp_delete_attachment( $th_id, true );
					}

					if( !$sku || !array_key_exists( $sku, $new_items ) ) {
						$prod->delete(true); //without trash
					} else {
						$this->up_prod_info( $prod, $new_items[$sku] );
						unset( $new_items[$sku] );
					}
				}
			}
			//create new products
			if ( count( $new_items ) ) {
				foreach ( $new_items as $prod_info ) {
					$this->up_prod_info(new WC_Product_Simple(), $prod_info);
				}
			}
		}

		/* update product info */
		private function up_prod_info( $prod, $info ) {
			//create new product also can use wp_insert_post() with add all needed meta, but better woo api
			$prod->set_name( $info['name'] );
			$prod->set_description ($info['description'] );
			$prod->set_sku( $info['sku'] );
			$price = preg_replace("/[^0-9\.]/", "", $info['price'] ); // remove everything except numbers and dot
			$prod->set_regular_price( $price ); //also maybe set_price, set_sale_price
			$prod->set_stock_quantity( $info['in_stock'] );
			$prod->save();
			if( $info['picture'] ) {
				$this->up_prod_th( $prod, $info['picture'] );
			}
			
		}

		/* upload new product thumbnail */
		private function up_prod_th( $prod, $th_url ) {
			if( !$prod || !$th_url ) return;

			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';

			/*
				// don't know why media_sideload_image doesn't want to work with url like 'https://loremflickr.com/640/480/abstract' -- need reseach,
				// but this variant works when url like "https://loremflickr.com/cache/resized/65535_52152971125_1b0135b250_b_640_480_nofilter.jpg" (so has name and file extension)
				// so made other variant 

				$th_img_id = media_sideload_image( $th_url, $prod->get_id(), sanitize_title( $prod->get_name().'-th' ), 'id' );
				if( !is_wp_error($th_img_id) ) {
					set_post_thumbnail( $prod->get_id() , $th_img_id );
				}
			*/

			$tmp = download_url( $th_url );
			if ( !is_wp_error( $tmp ) ) {

				$file_array = array();
				$file_array['name'] = sanitize_title( $prod->get_name().'-th' ).'.jpg'; // !!! need detect file extension dynamically wp_check_filetype() or something like this
				$file_array['tmp_name'] = $tmp;
				
				$th_img_id = media_handle_sideload( $file_array, $prod->get_id(), $prod->get_name() . ' - thumbnail' );
				
				if ( !is_wp_error( $th_img_id ) ) {
					set_post_thumbnail( $prod->get_id() , $th_img_id );
				}
			}
			@unlink( $tmp );

		}
	}
	
	//run
	$plugin_WebsparkProdSync = new WebsparkProdSync();

endif;